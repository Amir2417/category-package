Package Name : jatri/category.
Directory    : packages

Description  : I am writing to request a review of my submission for the Laravel package coding challenge. I have successfully completed the task and developed a package named category, which addresses all the key requirements outlined in the challenge. I have attached a Postman collection that demonstrates the CRUD operations of the package for your convenience.

Commands: composer update && php artisan migrate

